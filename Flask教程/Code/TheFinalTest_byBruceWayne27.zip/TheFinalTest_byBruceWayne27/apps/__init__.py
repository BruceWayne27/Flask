from flask import Flask,Blueprint,render_template
import settings #引入配置文件
from apps.admins.views import admin_bp #引入后台蓝图
from apps.exts import db#引入db
from apps.exts import login_manager#引入flask-login

def create_app():
    app = Flask(__name__)
    app.config.from_object(settings.DevelopmentConfig)#导入了开发者环境
    app.register_blueprint(admin_bp) #注册蓝图到app中
    db.init_app(app)#将SQLAlchemy的db对象和app进行关联
    login_manager.init_app(app)#关联flask-login

    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('notfound.html'), 404
    return app #返回app
