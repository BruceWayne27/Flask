from flask_sqlalchemy import SQLAlchemy #引入SQLAlchemy
db = SQLAlchemy() #创建db命令

from flask_login import LoginManager #配置flask-login
login_manager = LoginManager()
login_manager.login_view = 'admin_bp.login' #若用户没有登录自动跳转的界面
login_manager.session_protection = 'strong' #session保护等级
