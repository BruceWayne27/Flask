from apps.exts import db #引入db
from datetime import datetime #引入时间库
from flask_login import UserMixin
class User(db.Model,UserMixin):#用户表 flask-login需要继承UserMixin这样比较简单
    #表名
    __tablename__='users'
    #id 整型 主键自增
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    #用户名 字符型 不能空 不允许重复
    username = db.Column(db.String(15),nullable=False,unique=True)
    #密码  字符型 不能空
    pwd = db.Column(db.String(200),nullable=False)
    # eamil 不能空
    email = db.Column(db.String(100),nullable=False,unique=True)
    # 性别 不能空
    gender = db.Column(db.String(20),nullable=False)
    #注册日期  当前日期
    registdatae = db.Column(db.DateTime, default=datetime.now())
    #连表关联 这句话并不出现在数据库表属于orm的一个关系
    userlogs = db.relationship('UserLog',backref='user')
    def __str__(self):
        return self.username

    def check_pwd(self,pwd): #新增密码检查机制 会对明文密码和数据库已加密密码进行匹配
        from werkzeug.security import check_password_hash
        return check_password_hash(self.pwd,pwd)

class UserLog(db.Model):
    __tablename__ ='userlog'
    id = db.Column(db.Integer, primary_key=True)
    #登录时间
    logindatime = db.Column(db.DateTime, default=datetime.now())
    ip = db.Column(db.String(100)) #登录ip
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))#外键


    def __str__(self):
        return self.id