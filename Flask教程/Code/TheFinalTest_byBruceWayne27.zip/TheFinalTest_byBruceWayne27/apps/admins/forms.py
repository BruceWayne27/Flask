from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,SelectField,SubmitField,TextAreaField
from wtforms.validators import DataRequired,ValidationError,EqualTo,Length,Regexp
from apps.models import User
class RegisteForm(FlaskForm):
    #用户名 单行文本
    user = StringField(
        label='管理员账户',
        validators=[
            DataRequired('请输入账户！'),
            Length(min=4, max=6, message='用户名的长度4-6位'),
        ],
        description='管理员账户',
        render_kw={ #这里是样式
            "placeholder": "请输入账号！",
            "required": False,
        }
    )
    #密码
    pwd = PasswordField(
        label='密码',
        validators=[
            DataRequired('请输入密码'),
            Length(min=6,message='密码不小于4位'),
        ],
        description='管理员密码',
        render_kw={
            "placeholder": "请输入密码！",
            "required": False,
        }
    )
    #确认密码
    repwd = PasswordField(
        label='确认密码',
        validators=[
            DataRequired('请输入密码'),
            Length(min=6,message='密码不小于4位'),
            EqualTo('pwd',message='两次密码不一致'),#确认两次密码是不是一样
        ],
        description='管理员密码',
        render_kw={
            "placeholder": "请输入密码！",
            "required": False,
        }
    )
    #性别
    gender = SelectField(#单选框
        label='性别',
        validators=[
            DataRequired('请选择性别'),
        ],
        render_kw={
            "required": False,
        },
        choices=[('女','女'),('男','男')],
        coerce=str
    )
    #邮箱  由于内置Email方法因为WTF版本高冲突 使用正则表达式
    email = StringField(
        label='邮箱',
        validators=[
            #正则
            Regexp('^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$',message='邮箱格式错误'),
            DataRequired('请输入邮箱'),
        ],
    render_kw={
            "required": False,
            "placeholder": "请输入邮箱！",
        },

    )
    #提交按钮
    submit = SubmitField(
        '注册',
    )
    #自定义验证方法  def validate_<name>
    def validate_user(self,file):
        name = file.data
        user = User.query.filter_by(username=name).all()
        print('user',user)
        if user:
            raise ValidationError('用户名存在')

    def validate_email(self,file):
        email = file.data
        user = User.query.filter_by(email=email).all()
        if user:
            raise ValidationError('邮箱存在')




class LoginForm(FlaskForm):
    user = StringField(
        label='管理员账户',
        validators=[
            DataRequired('请输入账户！'),
        ],
        description='管理员账户',
        render_kw={  # 这里是样式
            "placeholder": "请输入账号！",
            "required": False,
        }
    )
    # 密码
    pwd = PasswordField(
        label='密码',
        validators=[
            DataRequired('请输入密码'),
        ],
        description='管理员密码',
        render_kw={
            "placeholder": "请输入密码！",
            "required": False,
        }
    )
    # 提交按钮
    submit = SubmitField(
        '登录',
    )


