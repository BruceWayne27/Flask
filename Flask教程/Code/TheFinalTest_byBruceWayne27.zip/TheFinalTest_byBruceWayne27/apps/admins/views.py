
#引入蓝图，render_template方法，flash闪现消息，request请求，url_for和redirect重定向获取session
from flask import Blueprint, render_template,flash,request,url_for,redirect,session
#从apps的exts文件夹引入sqlalchemy和flask-login
from apps.exts import db,login_manager
#从forms引入注册登录表单
from apps.admins.forms import RegisteForm,LoginForm
#从models引入orm数据库类
from apps.models import User,UserLog
from werkzeug.security import generate_password_hash #加密密码方法
#从flask-login引入必要方法
from flask_login import login_required,login_user,logout_user
admin_bp = Blueprint('admin_bp',__name__) #创建蓝图

@login_manager.user_loader
def user_is_login(userid):#flask-login构建方法来获得登录的id.
    getuserid = User.query.get(int(userid))
    print('getuserid &&userid',getuserid,userid)
    return getuserid

@admin_bp.route('/') #构建主页路由
@login_required#路由保护 如果没有登录即使通过输入index域名也不能访问
def index():
    userlogdata = UserLog.query.filter_by(
        user_id=session['_user_id']).order_by(#按照日志日期排序
        UserLog.logindatime.desc()
    )
    user = User.query.get(session['_user_id'])
    print("session['_user_id'] ",session['_user_id'] )
    return render_template('admins/index.html',user=user,userlogdata = userlogdata)#返回模板页面

@admin_bp.route('/login/',methods=['POST','GET']) #构建登录路由
def login():
    form = LoginForm() #实例化登录表单
    if form.validate_on_submit():#监听提交
        data = form.data
        print('data====',data)##这句话测试用的
        user = User.query.filter_by(username=data['user']).first() #查询user是否存在
        print('user==>',user)

        if user is not None and user.check_pwd(data["pwd"]):#如果user非空切密码正确
            login_user(user) #确认user登录了

            userloginid= int(user.id)#获得登录的id
            print('userloginid',userloginid)
            print('user.id', user.id)
            #添加登录日志
            userlog = UserLog(
                user_id=user.id,
                ip = request.remote_addr #内置方法获取ip
            )
            db.session.add(userlog)
            db.session.commit()
            #重定向到主页或者返回登录
            return redirect(request.args.get('next') or url_for('admin_bp.index'))
        flash('你的用户名或者密码错误','err')
    return render_template('admins/login.html',form=form)#返回模板页面

@admin_bp.route('/logout')
@login_required#路由保护 未登录 输入域名跳转会自动转到登录界面
def logout():
    logout_user()
    return redirect(url_for('admin_bp.login'))

@admin_bp.route('/regist',methods=['POST','GET'])
def regist():
    form = RegisteForm()#form用来获取前台的值
    if form.validate_on_submit():#监听提交
        data = form.data #拿到字典里的值
        user = User( #放入数据库
            username=data['user'],
            pwd= generate_password_hash(data['pwd']), #加密数据库
            gender= data['gender'],
            email=data["email"],
        )
        db.session.add(user) #添加数据
        db.session.commit() #提交
    return render_template('admins/regist.html',form=form)
'''
#装饰器路由保护获取session
from functools import wraps
# 登录装饰器
def admin_login_req(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "admin" not in session:
            return redirect(url_for("admin.login", next=request.url))
        return f(*args, **kwargs)

    return decorated_function
    
#登录
@admin.route("/login/", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        data = form.data
        admin = Admin.query.filter_by(name=data["account"]).first()
        if not admin.check_pwd(data["pwd"]):
            flash("密码错误！", 'err')
            return redirect(url_for("admin.login"))
        session["admin"] = data["account"]
        session["admin_id"] = admin.id
        adminlog = Adminlog(
            admin_id=admin.id,
            ip=request.remote_addr,
        )
        db.session.add(adminlog)
        db.session.commit()
        return redirect(request.args.get("next") or url_for("admin.index"))
    return render_template("admin/login.html", form=form)

# 修改密码
@admin.route("/pwd/", methods=["GET", "POST"])
@admin_login_req#路由保护
def pwd():
    form = PwdForm()
    if form.validate_on_submit():
        data = form.data
        admin = Admin.query.filter_by(name=session["admin"]).first()
        from werkzeug.security import generate_password_hash
        admin.pwd = generate_password_hash(data["new_pwd"])
        db.session.add(admin)
        db.session.commit()
        flash("修改密码成功，请重新登录！", "ok")
        redirect(url_for('admin.logout'))
    return render_template("admin/pwd.html", form=form)

# 退出
@admin.route("/logout/")
@admin_login_req
def logout():
    session.pop("admin_id", None)
    session.pop("admin", None)
    return redirect(url_for("admin.login"))
    

'''
