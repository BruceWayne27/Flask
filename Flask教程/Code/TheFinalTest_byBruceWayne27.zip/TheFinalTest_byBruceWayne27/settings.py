# settings.py
class Config:
    HOST = 'localhost'
    PORT = '3306'
    DATABASE = 'brucesql'
    USERNAME = 'bruce'
    PASSWORD = 'bruce27'

    DEBUG = 'True'#是否开启调试模式
    #mysql+pymysql://user:password@hostip:port/databasename
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://{username}:{password}@{host}:{port}/{db}?charset=utf8'.format(
        username = USERNAME,password = PASSWORD,host= HOST,port = PORT,db = DATABASE
    )
    # SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@localhost:3306/flasktest?charset=utf8'
    SQLALCHEMY_TRACK_MODIFICATIONS = False #跟踪  禁用提升性能
    SECRET_KEY = "EjpNVSNQTyGi1VvWECj9TvC/+kq3oujee2kTfQUs8yCM6xX9Yjq52v54g"
class DevelopmentConfig(Config):
    ENV = 'development' #开发环境
    SQLALCHEMY_ECHO = True  # 数据库调试模式

class ProductionConfig(Config):
    ENV = 'production'  #生产环境
    SQLALCHEMY_ECHO = False  # 数据库调试模式