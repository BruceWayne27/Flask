from apps import create_app #到处在apps里面创建的app
from flask_script import Manager
from flask_migrate import Migrate,MigrateCommand
from apps.exts import db #引入db
from apps import models #引入数据库ORM
''' 或者单个引入数据库表
from apps.models import User'''
app = create_app() #让app == appps里创建的app

manager = Manager(app = app) #第一个app是app关键字 第二个是app = create_app()
#命令工具
migrate = Migrate(app = app, db = db) #映射数据库
manager.add_command('db',MigrateCommand)#将命令交给manager处理

#启动
if __name__ == "__main__":
    manager.run()#用manager启动
